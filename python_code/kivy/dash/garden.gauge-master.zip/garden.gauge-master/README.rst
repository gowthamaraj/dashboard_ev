Gauge
=====

The class `Gauge` widget is a widget for displaying gauge. 

